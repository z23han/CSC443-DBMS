Downloaded From: http://proj.ise.bgu.ac.il/sns

Google+ is a social networking service and website offered by Google. A Google+ member can add any other member to his circles, creating a directed social graph. We used a dedicated crawler to obtain this dataset.
Please Cite:

Computationally Efficient Link Prediction in Variety of Social Networks, Michael Fire, Lena Tenenboim, Rami Puzis, Ofrit Lesser, Lior Rokach, Yuval Elovici, 2012
Bibtex:
@inproceedings{

@article{

title={Computationally Efficient Link Prediction in Variety of Social Networks},
author={Fire, M. and Tenenboim, L. and Puzis, R. and Lesser, O. and Rokach, L. and Elovici, Y.},
year={2012},
}
